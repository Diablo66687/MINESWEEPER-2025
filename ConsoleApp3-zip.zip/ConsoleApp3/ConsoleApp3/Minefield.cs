using System;

namespace ConsoleApp3
{
    public class Minefield
    {
        public enum CellState { Hidden, Revealed, Flagged }
        public struct Cell
        {
            public bool HasMine;
            public int AdjacentMines;
            public CellState State;
        }

        public int Width { get; }
        public int Height { get; }
        public int MineCount { get; }
        public Cell[,] Grid { get; }
        private Random _rand = new();

        public Minefield(int width, int height, int mineCount)
        {
            Width = width;
            Height = height;
            MineCount = mineCount;
            Grid = new Cell[width, height];
            PlaceMines();
            CalculateAdjacents();
        }

        private void PlaceMines()
        {
            int placed = 0;
            while (placed < MineCount)
            {
                int x = _rand.Next(Width);
                int y = _rand.Next(Height);
                if (!Grid[x, y].HasMine)
                {
                    Grid[x, y].HasMine = true;
                    placed++;
                }
            }
        }

        private void CalculateAdjacents()
        {
            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    if (Grid[x, y].HasMine) continue;
                    int count = 0;
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        for (int dy = -1; dy <= 1; dy++)
                        {
                            int nx = x + dx, ny = y + dy;
                            if (nx >= 0 && nx < Width && ny >= 0 && ny < Height && Grid[nx, ny].HasMine)
                                count++;
                        }
                    }
                    Grid[x, y].AdjacentMines = count;
                }
            }
        }

        public bool Reveal(int x, int y)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return false;
            if (Grid[x, y].State != CellState.Hidden) return false;
            Grid[x, y].State = CellState.Revealed;
            if (Grid[x, y].HasMine) return true;
            if (Grid[x, y].AdjacentMines == 0)
            {
                for (int dx = -1; dx <= 1; dx++)
                {
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        int nx = x + dx, ny = y + dy;
                        if (nx >= 0 && nx < Width && ny >= 0 && ny < Height)
                            Reveal(nx, ny);
                    }
                }
            }
            return false;
        }

        public void ToggleFlag(int x, int y)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return;
            if (Grid[x, y].State == CellState.Hidden)
                Grid[x, y].State = CellState.Flagged;
            else if (Grid[x, y].State == CellState.Flagged)
                Grid[x, y].State = CellState.Hidden;
        }
    }
}
