﻿using System;
using System.Collections.Generic;
using static ConsoleApp3.Minefield;

namespace ConsoleApp3
{
    internal class Program
    {
        static Dictionary<string, Dictionary<string, string>> texts = new()
        {
            ["en"] = new() {
                ["menu_play"] = "Play",
                ["menu_how"] = "How to play",
                ["menu_top"] = "Leaderboard",
                ["menu_lang"] = "Language",
                ["menu_exit"] = "Exit",
                ["menu_title"] = "MINESWEEPER 2025",
                ["menu_select"] = "Choose an option (W/S + Enter):",
                ["legend_controls"] = "Controls: W/A/S/D or arrows - move, Enter - reveal, F - flag",
                ["legend_action"] = "Select a cell and press Enter or F.",
                ["legend_level"] = "Level",
                ["legend_mines"] = "Mines",
                ["legend_flags"] = "Flags",
                ["legend_time"] = "Time left",
                ["thanks"] = "Thank you for playing! Created by DevBrain © www.devbrain.cz",
                ["devbrain"] = "Created by DevBrain © www.devbrain.cz",
                ["congrats"] = "Congratulations! You completed bonus level 100!",
                ["menu_stats"] = "Statistics",
                ["no_scores"] = "No scores yet.",
                ["contact_title"] = "Contact & Feedback",
                ["online_leaderboard"] = "Online Leaderboard (demo)",
                ["online_info"] = "Visit www.devbrain.cz for the full leaderboard"
            },
            ["de"] = new() {
                ["menu_play"] = "Spielen",
                ["menu_how"] = "Spielanleitung",
                ["menu_top"] = "Bestenliste",
                ["menu_lang"] = "Sprache",
                ["menu_exit"] = "Beenden",
                ["menu_title"] = "MINENSUCHER 2025",
                ["menu_select"] = "Option wählen (W/S + Enter):",
                ["legend_controls"] = "Steuerung: W/A/S/D oder Pfeile - bewegen, Enter - aufdecken, F - markieren",
                ["legend_action"] = "Wähle ein Feld und drücke Enter oder F.",
                ["legend_level"] = "Level",
                ["legend_mines"] = "Minen",
                ["legend_flags"] = "Markierungen",
                ["legend_time"] = "Verbleibende Zeit",
                ["thanks"] = "Danke fürs Spielen! Erstellt von DevBrain © www.devbrain.cz",
                ["devbrain"] = "Erstellt von DevBrain © www.devbrain.cz",
                ["congrats"] = "Glückwunsch! Du hast Bonuslevel 100 geschafft!",
                ["menu_stats"] = "Statistiken",
                ["no_scores"] = "Noch keine Ergebnisse.",
                ["contact_title"] = "Kontakt & Feedback",
                ["online_leaderboard"] = "Online-Bestenliste (Demo)",
                ["online_info"] = "Besuchen Sie www.devbrain.cz für die vollständige Rangliste"
            },
            ["pl"] = new() {
                ["menu_play"] = "Graj",
                ["menu_how"] = "Jak grać",
                ["menu_top"] = "Ranking",
                ["menu_lang"] = "Język",
                ["menu_exit"] = "Wyjście",
                ["menu_title"] = "SAPER 2025",
                ["menu_select"] = "Wybierz opcję (W/S + Enter):",
                ["legend_controls"] = "Sterowanie: W/A/S/D lub strzałki - ruch, Enter - odkryj, F - flaga",
                ["legend_action"] = "Wybierz pole i naciśnij Enter lub F.",
                ["legend_level"] = "Poziom",
                ["legend_mines"] = "Miny",
                ["legend_flags"] = "Flagi",
                ["legend_time"] = "Pozostały czas",
                ["thanks"] = "Dziękujemy za grę! Stworzone przez DevBrain © www.devbrain.cz",
                ["devbrain"] = "Stworzone przez DevBrain © www.devbrain.cz",
                ["congrats"] = "Gratulacje! Ukończyłeś bonusowy poziom 100!",
                ["menu_stats"] = "Statystyki",
                ["no_scores"] = "Brak wyników.",
                ["contact_title"] = "Kontakt i opinie",
                ["online_leaderboard"] = "Ranking online (demo)",
                ["online_info"] = "Pełny ranking na www.devbrain.cz"
            },
            ["ua"] = new() {
                ["menu_play"] = "Грати",
                ["menu_how"] = "Як грати",
                ["menu_top"] = "Таблиця лідерів",
                ["menu_lang"] = "Мова",
                ["menu_exit"] = "Вихід",
                ["menu_title"] = "МІНОШУКАЧ 2025",
                ["menu_select"] = "Виберіть опцію (W/S + Enter):",
                ["legend_controls"] = "Управління: W/A/S/D або стрілки - рух, Enter - відкрити, F - прапор",
                ["legend_action"] = "Виберіть клітинку і натисніть Enter або F.",
                ["legend_level"] = "Рівень",
                ["legend_mines"] = "Міни",
                ["legend_flags"] = "Прапори",
                ["legend_time"] = "Залишилось часу",
                ["thanks"] = "Дякуємо за гру! Створено DevBrain © www.devbrain.cz",
                ["devbrain"] = "Створено DevBrain © www.devbrain.cz",
                ["congrats"] = "Вітаємо! Ви пройшли бонусний рівень 100!",
                ["menu_stats"] = "Статистика",
                ["no_scores"] = "Ще немає результатів.",
                ["contact_title"] = "Контакт та відгуки",
                ["online_leaderboard"] = "Онлайн рейтинг (демо)",
                ["online_info"] = "Повний рейтинг на www.devbrain.cz"
            },
            ["fr"] = new() {
                ["menu_play"] = "Jouer",
                ["menu_how"] = "Comment jouer",
                ["menu_top"] = "Classement",
                ["menu_lang"] = "Langue",
                ["menu_exit"] = "Quitter",
                ["menu_title"] = "DÉMINAGE 2025",
                ["menu_select"] = "Choisissez une option (W/S + Entrée):",
                ["legend_controls"] = "Contrôles: W/A/S/D ou flèches - déplacer, Entrée - révéler, F - drapeau",
                ["legend_action"] = "Sélectionnez une case et appuyez sur Entrée ou F.",
                ["legend_level"] = "Niveau",
                ["legend_mines"] = "Mines",
                ["legend_flags"] = "Drapeaux",
                ["legend_time"] = "Temps restant",
                ["thanks"] = "Merci d'avoir joué! Créé par DevBrain © www.devbrain.cz",
                ["devbrain"] = "Créé par DevBrain © www.devbrain.cz",
                ["congrats"] = "Félicitations! Vous avez terminé le niveau bonus 100!",
                ["menu_stats"] = "Statistiques",
                ["no_scores"] = "Pas encore de scores.",
                ["contact_title"] = "Contact & Retour",
                ["online_leaderboard"] = "Classement en ligne (démo)",
                ["online_info"] = "Classement complet sur www.devbrain.cz"
            },
            ["es"] = new() {
                ["menu_play"] = "Jugar",
                ["menu_how"] = "Cómo jugar",
                ["menu_top"] = "Clasificación",
                ["menu_lang"] = "Idioma",
                ["menu_exit"] = "Salir",
                ["menu_title"] = "BUSCAMINAS 2025",
                ["menu_select"] = "Selecciona opción (W/S + Enter):",
                ["legend_controls"] = "Controles: W/A/S/D o flechas - mover, Enter - revelar, F - bandera",
                ["legend_action"] = "Selecciona una celda y pulsa Enter o F.",
                ["legend_level"] = "Nivel",
                ["legend_mines"] = "Minas",
                ["legend_flags"] = "Banderas",
                ["legend_time"] = "Tiempo restante",
                ["thanks"] = "¡Gracias por jugar! Creado por DevBrain © www.devbrain.cz",
                ["devbrain"] = "Creado por DevBrain © www.devbrain.cz",
                ["congrats"] = "¡Felicidades! Completaste el nivel extra 100!",
                ["menu_stats"] = "Estadísticas",
                ["no_scores"] = "Sin resultados todavía.",
                ["contact_title"] = "Contacto y comentarios",
                ["online_leaderboard"] = "Clasificación online (demo)",
                ["online_info"] = "Clasificación completa en www.devbrain.cz"
            }
        };

        static string lang;
        static string T(string key) => texts[lang].ContainsKey(key) ? texts[lang][key] : key;

        static void Main(string[] args)
        {
            lang = AppSettings?.Language ?? "en";
            ShowMenu();
        }

        static void ShowMenu()
        {
            lang = AppSettings?.Language ?? "en"; // vždy načíst aktuální jazyk
            string[] menuItems = { "menu_play", "loadgame", "menu_how", "menu_top", "menu_lang", "theme", "contact", "online", "menu_exit", "stats" };
            int selected = 0;
            bool running = true;
            while (running)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\n╔════════════════════════════════════╗");
                Console.WriteLine($"║   {T("menu_title"),-30}        ║");
                Console.WriteLine("╚════════════════════════════════════╝\n");
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine($"{T("devbrain")}");
                Console.ResetColor();
                for (int i = 0; i < menuItems.Length; i++)
                {
                    if (i == selected)
                    {
                        Console.BackgroundColor = ConsoleColor.Cyan;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine($" ▶ {(menuItems[i] == "stats" ? T("menu_stats") : T(menuItems[i]))}");
                    }
                    else
                    {
                        Console.WriteLine($"   {(menuItems[i] == "stats" ? T("menu_stats") : T(menuItems[i]))}");
                    }
                    Console.ResetColor();
                }
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine($"\n{T("menu_select")}");
                Console.ResetColor();
                var key = Console.ReadKey(true).Key;
                switch (key)
                {
                    case ConsoleKey.W:
                        if (selected > 0) selected--;
                        break;
                    case ConsoleKey.S:
                        if (selected < menuItems.Length - 1) selected++;
                        break;
                    case ConsoleKey.Enter:
                        switch (menuItems[selected])
                        {
                            case "menu_play":
                                StartGame();
                                break;
                            case "loadgame":
                                StartLoadedGame();
                                break;
                            case "menu_how":
                                ShowHowToPlay();
                                break;
                            case "menu_top":
                                ShowTop5();
                                break;
                            case "menu_lang":
                                SelectLanguage();
                                lang = AppSettings?.Language ?? "en"; // aktualizace jazyka po volbě
                                break;
                            case "theme":
                                ShowThemeMenu();
                                break;
                            case "contact":
                                ShowContact();
                                break;
                            case "online":
                                ShowOnlineLeaderboard();
                                break;
                            case "stats":
                                ShowStats();
                                break;
                            case "menu_exit":
                                running = false;
                                break;
                        }
                        break;
                }
            }
        }

        static void ShowHowToPlay()
        {
            lang = AppSettings?.Language ?? "en";
            Console.Clear();
            Console.WriteLine("\n" + T("menu_how") + "\n");
            Console.WriteLine("- " + T("legend_controls"));
            Console.WriteLine("- Enter: " + T("legend_action"));
            Console.WriteLine("- " + T("legend_level") + ": " + T("legend_mines") + ", " + T("legend_flags"));
            Console.WriteLine("- " + T("legend_time"));
            Console.WriteLine("- F: flag, H: help, Esc: menu");
            Console.WriteLine("\n" + T("menu_select"));
            Console.ReadKey(true);
        }

        static void ShowTop5()
        {
            lang = AppSettings?.Language ?? "en";
            bool back = false;
            while (!back)
            {
                Console.Clear();
                Console.WriteLine("\nTOP 5 (" + T("legend_level") + ")");
                var scores = LoadHighScores();
                if (scores.Count == 0)
                    Console.WriteLine(T("no_scores"));
                else
                    for (int i = 0; i < scores.Count; i++)
                        Console.WriteLine($"{i + 1}. {scores[i].Name} - {T("legend_level")}: {scores[i].Level}");
                Console.WriteLine("\n" + T("menu_select"));
                var key = Console.ReadKey(true).Key;
                if (key == ConsoleKey.Enter || key == ConsoleKey.Escape)
                    back = true;
            }
        }

        static void SelectLanguage()
        {
            string[] langs = { "en", "de", "pl", "ua", "fr", "es" };
            int selected = Array.IndexOf(langs, lang);
            bool choosing = true;
            while (choosing)
            {
                Console.Clear();
                Console.WriteLine("\n" + T("menu_lang") + ":");
                for (int i = 0; i < langs.Length; i++)
                {
                    if (i == selected)
                    {
                        Console.BackgroundColor = ConsoleColor.Cyan;
                        Console.ForegroundColor = ConsoleColor.Black;
                    }
                    Console.WriteLine($"  {T("lang_" + langs[i])}");
                    Console.ResetColor();
                }
                Console.WriteLine("\nStiskni Enter pro potvrzení nebo Esc pro návrat do hlavního menu...");
                var key = Console.ReadKey(true).Key;
                switch (key)
                {
                    case ConsoleKey.W:
                        if (selected > 0) selected--;
                        break;
                    case ConsoleKey.S:
                        if (selected < langs.Length - 1) selected++;
                        break;
                    case ConsoleKey.Enter:
                        lang = langs[selected];
                        AppSettings.Language = lang;
                        SaveSettings();
                        choosing = false;
                        break;
                    case ConsoleKey.Escape:
                        choosing = false;
                        break;
                }
            }
        }

        static void ShowThemeMenu()
        {
            string[] themes = { "dark", "light" };
            int selected = Array.IndexOf(themes, AppSettings.Theme);
            bool choosing = true;
            while (choosing)
            {
                Console.Clear();
                Console.WriteLine("\nVyberte barevný motiv:");
                for (int i = 0; i < themes.Length; i++)
                {
                    if (i == selected)
                    {
                        Console.BackgroundColor = ConsoleColor.Cyan;
                        Console.ForegroundColor = ConsoleColor.Black;
                    }
                    Console.WriteLine($"  {(themes[i] == "dark" ? "Tmavý" : "Světlý")}");
                    Console.ResetColor();
                }
                Console.WriteLine("\nStiskni Enter pro potvrzení nebo Esc pro návrat do hlavního menu...");
                var key = Console.ReadKey(true).Key;
                switch (key)
                {
                    case ConsoleKey.W:
                        if (selected > 0) selected--;
                        break;
                    case ConsoleKey.S:
                        if (selected < themes.Length - 1) selected++;
                        break;
                    case ConsoleKey.Enter:
                        AppSettings.Theme = themes[selected];
                        SaveSettings();
                        choosing = false;
                        break;
                    case ConsoleKey.Escape:
                        choosing = false;
                        break;
                }
            }
        }

        static void DrawField(Minefield field, int cursorX, int cursorY, bool revealAll = false)
        {
            // Rámeček horní
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("   ");
            for (int x = 0; x < field.Width; x++) Console.Write($" {x + 1,2}");
            Console.WriteLine();
            Console.Write("   ");
            Console.Write("┌" + new string('─', field.Width * 3) + "┐");
            Console.WriteLine();
            for (int y = 0; y < field.Height; y++)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{y + 1,2} │");
                for (int x = 0; x < field.Width; x++)
                {
                    var cell = field.Grid[x, y];
                    bool selected = (x == cursorX && y == cursorY);
                    if (selected)
                    {
                        Console.BackgroundColor = ConsoleColor.Cyan;
                        Console.ForegroundColor = ConsoleColor.Black;
                    }
                    else if (revealAll && cell.HasMine)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    else if (cell.State == CellState.Hidden)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkGray;
                    }
                    else if (cell.State == CellState.Flagged)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                    }
                    else if (cell.HasMine)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    else
                    {
                        Console.ForegroundColor = cell.AdjacentMines switch
                        {
                            1 => ConsoleColor.Blue,
                            2 => ConsoleColor.Green,
                            3 => ConsoleColor.Red,
                            4 => ConsoleColor.DarkBlue,
                            5 => ConsoleColor.DarkRed,
                            6 => ConsoleColor.Cyan,
                            7 => ConsoleColor.Magenta,
                            8 => ConsoleColor.DarkGray,
                            _ => ConsoleColor.White
                        };
                    }
                    // Zobrazení symbolu
                    if (revealAll && cell.HasMine)
                        Console.Write(" * ");
                    else if (cell.State == CellState.Hidden)
                        Console.Write(" # ");
                    else if (cell.State == CellState.Flagged)
                        Console.Write(" F ");
                    else if (cell.HasMine)
                        Console.Write(" * ");
                    else
                        Console.Write(cell.AdjacentMines > 0 ? $" {cell.AdjacentMines} " : "   ");
                    Console.ResetColor();
                }
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("│");
            }
            // Rámeček dolní
            Console.Write("   ");
            Console.WriteLine("└" + new string('─', field.Width * 3) + "┘");
            Console.ResetColor();
        }

        static bool CheckWin(Minefield field)
        {
            for (int x = 0; x < field.Width; x++)
                for (int y = 0; y < field.Height; y++)
                    if (!field.Grid[x, y].HasMine && field.Grid[x, y].State != CellState.Revealed)
                        return false;
            return true;
        }

        static void StartGame()
        {
            int maxLevel = 100;
            int currentLevel = LoadLastLevel();
            bool finished = false;
            int reachedLevel = currentLevel;
            while (!finished && currentLevel <= maxLevel)
            {
                int width, height, mines, timeLimit;
                if (currentLevel < 100)
                {
                    width = Math.Min(9 + currentLevel / 5, 30);
                    height = Math.Min(9 + currentLevel / 5, 24);
                    mines = Math.Min(10 + currentLevel * 2, width * height - 1);
                    timeLimit = Math.Max(60 - currentLevel / 2, 10); // seconds
                }
                else
                {
                    width = 10;
                    height = 10;
                    mines = width * height - 1;
                    timeLimit = 30;
                }
                var field = new Minefield(width, height, mines);
                int cursorX = 0, cursorY = 0;
                bool gameOver = false;
                DateTime startTime = DateTime.Now;
                while (!gameOver)
                {
                    Console.Clear();
                    DrawField(field, cursorX, cursorY);
                    int flagged = 0;
                    for (int x = 0; x < width; x++)
                        for (int y = 0; y < height; y++)
                            if (field.Grid[x, y].State == CellState.Flagged) flagged++;
                    int secondsLeft = timeLimit - (int)(DateTime.Now - startTime).TotalSeconds;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine($"{T("legend_level")}: {currentLevel}  {T("legend_mines")}: {mines}  {T("legend_flags")}: {flagged}  {T("legend_time")}: {secondsLeft}s");
                    Console.WriteLine(T("legend_controls"));
                    Console.WriteLine(T("legend_action"));
                    Console.ResetColor();
                    if (secondsLeft <= 0)
                    {
                        Console.Clear();
                        DrawField(field, cursorX, cursorY, revealAll:true);
                        Console.WriteLine("Čas vypršel! Prohrál jsi.");
                        gameOver = true;
                        break;
                    }
                    var key = Console.ReadKey(true).Key;
                    switch (key)
                    {
                        case ConsoleKey.W:
                        case ConsoleKey.UpArrow:
                            if (cursorY > 0) cursorY--;
                            break;
                        case ConsoleKey.S:
                        case ConsoleKey.DownArrow:
                            if (cursorY < height - 1) cursorY++;
                            break;
                        case ConsoleKey.A:
                        case ConsoleKey.LeftArrow:
                            if (cursorX > 0) cursorX--;
                            break;
                        case ConsoleKey.D:
                        case ConsoleKey.RightArrow:
                            if (cursorX < width - 1) cursorX++;
                            break;
                        case ConsoleKey.F:
                            field.ToggleFlag(cursorX, cursorY);
                            break;
                        case ConsoleKey.Escape:
                            gameOver = true;
                            break;
                        case ConsoleKey.H:
                            ShowHelp();
                            break;
                        case ConsoleKey.Enter:
                            if (field.Reveal(cursorX, cursorY))
                            {
                                Console.Clear();
                                DrawField(field, cursorX, cursorY, revealAll:true);
                                AnimateExplosion(cursorX, cursorY, field);
                                Console.WriteLine("BOOM! Prohrál jsi.");
                                gameOver = true;
                            }
                            else if (CheckWin(field))
                            {
                                Console.Clear();
                                DrawField(field, cursorX, cursorY, revealAll:true);
                                if (currentLevel == maxLevel)
                                {
                                    Console.WriteLine(T("congrats"));
                                    Console.WriteLine(T("thanks"));
                                    Console.WriteLine("Zadej své jméno pro zápis do TOP 5:");
                                    string nameForTop5Final = Console.ReadLine();
                                    AddHighScore(nameForTop5Final, currentLevel);
                                    SaveLastLevel(1);
                                    finished = true;
                                }
                                else
                                {
                                    Console.WriteLine($"{T("legend_level")}: {currentLevel} {T("congrats")}");
                                    Console.WriteLine("Pokračovat na další level? (Enter = ano, Esc = menu)");
                                    var nextKey = Console.ReadKey(true).Key;
                                    if (nextKey == ConsoleKey.Enter)
                                        currentLevel++;
                                    else
                                        finished = true;
                                }
                            }
                            break;
                    }
                }
                if (gameOver && !CheckWin(field))
                {
                    Console.WriteLine("Stiskni libovolnou klávesu pro návrat do menu...");
                    Console.ReadKey(true);
                    finished = true;
                }
                if (CheckWin(field) && currentLevel < maxLevel)
                {
                    SaveLastLevel(currentLevel + 1);
                }
            }
            // Po ukončení hry nabídka zápisu do TOP 5
            var stats = LoadStats();
            stats.GamesPlayed++;
            stats.TotalLevels += reachedLevel;
            if (reachedLevel == maxLevel)
                stats.GamesWon++;
            else
                stats.GamesLost++;
            SaveStats(stats);
            Console.Clear();
            Console.WriteLine($"{T("legend_level")}: {reachedLevel}");
            Console.WriteLine("Zadej své jméno pro zápis do TOP 5:");
            string nameForTop5 = Console.ReadLine();
            AddHighScore(nameForTop5, reachedLevel);
            Console.WriteLine("Výsledek uložen. Stiskni Enter pro návrat do menu...");
            Console.ReadKey(true);
        }

        static void StartLoadedGame()
        {
            var loaded = LoadGame();
            if (loaded == null)
            {
                Console.Clear();
                Console.WriteLine("\nŽádná uložená hra nebyla nalezena.");
                Console.WriteLine("\nStiskni Enter pro návrat do hlavního menu...");
                Console.ReadKey(true);
                return;
            }
            int currentLevel = loaded.Value.Item1;
            Minefield field = loaded.Value.Item2;
            int cursorX = loaded.Value.Item3;
            int cursorY = loaded.Value.Item4;
            int maxLevel = 100;
            bool finished = false;
            int reachedLevel = currentLevel;
            int width = field.Width;
            int height = field.Height;
            int mines = field.MineCount;
            int timeLimit = Math.Max(60 - currentLevel / 2, 10);
            DateTime startTime = DateTime.Now;
            while (!finished && currentLevel <= maxLevel)
            {
                bool gameOver = false;
                while (!gameOver)
                {
                    Console.Clear();
                    DrawField(field, cursorX, cursorY);
                    int flagged = 0;
                    for (int x = 0; x < width; x++)
                        for (int y = 0; y < height; y++)
                            if (field.Grid[x, y].State == Minefield.CellState.Flagged) flagged++;
                    int secondsLeft = timeLimit - (int)(DateTime.Now - startTime).TotalSeconds;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine($"{T("legend_level")}: {currentLevel}  {T("legend_mines")}: {mines}  {T("legend_flags")}: {flagged}  {T("legend_time")}: {secondsLeft}s");
                    Console.WriteLine(T("legend_controls"));
                    Console.WriteLine(T("legend_action"));
                    Console.ResetColor();
                    if (secondsLeft <= 0)
                    {
                        Console.Clear();
                        DrawField(field, cursorX, cursorY, revealAll:true);
                        Console.WriteLine("Čas vypršel! Prohrál jsi.");
                        gameOver = true;
                        break;
                    }
                    var key = Console.ReadKey(true).Key;
                    switch (key)
                    {
                        case ConsoleKey.W:
                        case ConsoleKey.UpArrow:
                            if (cursorY > 0) cursorY--;
                            break;
                        case ConsoleKey.S:
                        case ConsoleKey.DownArrow:
                            if (cursorY < height - 1) cursorY++;
                            break;
                        case ConsoleKey.A:
                        case ConsoleKey.LeftArrow:
                            if (cursorX > 0) cursorX--;
                            break;
                        case ConsoleKey.D:
                        case ConsoleKey.RightArrow:
                            if (cursorX < width - 1) cursorX++;
                            break;
                        case ConsoleKey.F:
                            field.ToggleFlag(cursorX, cursorY);
                            break;
                        case ConsoleKey.Escape:
                            gameOver = true;
                            break;
                        case ConsoleKey.H:
                            ShowHelp();
                            break;
                        case ConsoleKey.Enter:
                            if (field.Reveal(cursorX, cursorY))
                            {
                                Console.Clear();
                                DrawField(field, cursorX, cursorY, revealAll:true);
                                AnimateExplosion(cursorX, cursorY, field);
                                Console.WriteLine("BOOM! Prohrál jsi.");
                                gameOver = true;
                            }
                            else if (CheckWin(field))
                            {
                                Console.Clear();
                                DrawField(field, cursorX, cursorY, revealAll:true);
                                Console.WriteLine($"{T("legend_level")}: {currentLevel} {T("congrats")}");
                                Console.WriteLine("Pokračovat na další level? (Enter = ano, Esc = menu)");
                                var nextKey = Console.ReadKey(true).Key;
                                if (nextKey == ConsoleKey.Enter)
                                    currentLevel++;
                                else
                                    finished = true;
                                gameOver = true;
                            }
                            break;
                    }
                }
                if (gameOver && !CheckWin(field))
                {
                    Console.WriteLine("Stiskni libovolnou klávesu pro návrat do menu...");
                    Console.ReadKey(true);
                    finished = true;
                }
                if (CheckWin(field) && currentLevel < maxLevel)
                {
                    SaveLastLevel(currentLevel + 1);
                }
            }
            // Po ukončení hry smaž uloženou hru
            if (System.IO.File.Exists("savegame.json"))
                System.IO.File.Delete("savegame.json");
        }

        static void SaveGame(int level, Minefield field, int cursorX, int cursorY)
        {
            var gridData = new List<string>();
            for (int x = 0; x < field.Width; x++)
                for (int y = 0; y < field.Height; y++)
                {
                    var c = field.Grid[x, y];
                    gridData.Add($"{x},{y},{c.HasMine},{c.AdjacentMines},{(int)c.State}");
                }
            var save = new {
                Level = level,
                Width = field.Width,
                Height = field.Height,
                Mines = field.MineCount,
                CursorX = cursorX,
                CursorY = cursorY,
                Grid = gridData
            };
            var json = System.Text.Json.JsonSerializer.Serialize(save);
            System.IO.File.WriteAllText("savegame.json", json);
        }
        static (int, Minefield, int, int)? LoadGame()
        {
            if (!System.IO.File.Exists("savegame.json")) return null;
            var json = System.IO.File.ReadAllText("savegame.json");
            var save = System.Text.Json.JsonDocument.Parse(json).RootElement;
            int level = save.GetProperty("Level").GetInt32();
            int width = save.GetProperty("Width").GetInt32();
            int height = save.GetProperty("Height").GetInt32();
            int mines = save.GetProperty("Mines").GetInt32();
            int cursorX = save.GetProperty("CursorX").GetInt32();
            int cursorY = save.GetProperty("CursorY").GetInt32();
            var field = new Minefield(width, height, mines);
            var gridArr = save.GetProperty("Grid").EnumerateArray();
            foreach (var item in gridArr)
            {
                var parts = item.GetString().Split(',');
                int x = int.Parse(parts[0]);
                int y = int.Parse(parts[1]);
                field.Grid[x, y].HasMine = bool.Parse(parts[2]);
                field.Grid[x, y].AdjacentMines = int.Parse(parts[3]);
                field.Grid[x, y].State = (CellState)int.Parse(parts[4]);
            }
            return (level, field, cursorX, cursorY);
        }

        static int LoadLastLevel()
        {
            string file = "lastlevel.txt";
            if (System.IO.File.Exists(file) && int.TryParse(System.IO.File.ReadAllText(file), out int lvl) && lvl >= 1 && lvl <= 100)
                return lvl;
            return 1;
        }
        static void SaveLastLevel(int lvl)
        {
            System.IO.File.WriteAllText("lastlevel.txt", lvl.ToString());
        }

        class HighScoreEntry
        {
            public string Name { get; set; }
            public int Level { get; set; }
        }

        static string highScoreFile = "highscore.txt";
        static List<HighScoreEntry> LoadHighScores()
        {
            var list = new List<HighScoreEntry>();
            if (!System.IO.File.Exists(highScoreFile)) return list;
            foreach (var line in System.IO.File.ReadAllLines(highScoreFile))
            {
                var parts = line.Split(';');
                if (parts.Length == 2 && int.TryParse(parts[1], out int lvl))
                    list.Add(new HighScoreEntry { Name = parts[0], Level = lvl });
            }
            return list.OrderByDescending(e => e.Level).Take(5).ToList();
        }
        static void SaveHighScores(List<HighScoreEntry> scores)
        {
            System.IO.File.WriteAllLines(highScoreFile, scores.OrderByDescending(e => e.Level).Take(5).Select(e => $"{e.Name};{e.Level}"));
        }
        static void AddHighScore(string name, int level)
        {
            var scores = LoadHighScores();
            scores.Add(new HighScoreEntry { Name = name, Level = level });
            var top5 = scores.OrderByDescending(e => e.Level).Take(5).ToList();
            SaveHighScores(top5);
        }
        class Settings
        {
            public string Language { get; set; } = "en";
            public string Theme { get; set; } = "dark";
        }
        static string settingsFile = "settings.json";
        static Settings AppSettings = LoadSettings();
        static Settings LoadSettings()
        {
            if (System.IO.File.Exists(settingsFile))
            {
                var json = System.IO.File.ReadAllText(settingsFile);
                return System.Text.Json.JsonSerializer.Deserialize<Settings>(json) ?? new Settings();
            }
            return new Settings();
        }
        static void SaveSettings()
        {
            var json = System.Text.Json.JsonSerializer.Serialize(AppSettings);
            System.IO.File.WriteAllText(settingsFile, json);
        }
        class Stats
        {
            public int GamesPlayed { get; set; }
            public int GamesWon { get; set; }
            public int GamesLost { get; set; }
            public int TotalLevels { get; set; }
            public double AvgLevel => GamesPlayed > 0 ? (double)TotalLevels / GamesPlayed : 0;
        }
        static Stats LoadStats()
        {
            string file = "stats.json";
            if (System.IO.File.Exists(file))
            {
                var json = System.IO.File.ReadAllText(file);
                return System.Text.Json.JsonSerializer.Deserialize<Stats>(json) ?? new Stats();
            }
            return new Stats();
        }
        static void SaveStats(Stats stats)
        {
            var json = System.Text.Json.JsonSerializer.Serialize(stats);
            System.IO.File.WriteAllText("stats.json", json);
        }

        static void ShowStats()
        {
            lang = AppSettings?.Language ?? "en";
            Console.Clear();
            var stats = LoadStats();
            Console.WriteLine("\n" + T("menu_stats") + "\n");
            Console.WriteLine($"{T("legend_level")}: {stats.GamesPlayed}");
            Console.WriteLine($"{T("legend_mines")}: {stats.GamesWon}");
            Console.WriteLine($"{T("legend_flags")}: {stats.GamesLost}");
            Console.WriteLine($"Total Levels Completed: {stats.TotalLevels}");
            Console.WriteLine($"Average Level: {stats.AvgLevel:F1}");
            Console.WriteLine("\n" + T("menu_select"));
            Console.ReadKey(true);
        }

        static void AnimateExplosion(int x, int y, Minefield field)
        {
            for (int i = 0; i < 6; i++)
            {
                Console.SetCursorPosition(4 + x * 3, 3 + y);
                Console.BackgroundColor = i % 2 == 0 ? ConsoleColor.Red : ConsoleColor.Yellow;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.Write(" * ");
                Console.ResetColor();
                System.Threading.Thread.Sleep(120);
            }
            Console.SetCursorPosition(0, field.Height + 5);
        }

        static void ShowHelp()
        {
            lang = AppSettings?.Language ?? "en";
            Console.Clear();
            Console.WriteLine("\n" + T("menu_how") + ":");
            Console.WriteLine("- " + T("legend_controls"));
            Console.WriteLine("- " + T("legend_action"));
            Console.WriteLine("- " + T("legend_level") + ", " + T("legend_mines") + ", " + T("legend_flags"));
            Console.WriteLine("- " + T("legend_time"));
            Console.WriteLine("- F: flag, H: help, Esc: menu");
            Console.WriteLine("\n" + T("menu_select"));
            Console.ReadKey(true);
        }

        static void ShowContact()
        {
            lang = AppSettings?.Language ?? "en";
            Console.Clear();
            Console.WriteLine("\n" + T("contact_title") + ":");
            Console.WriteLine("Web: www.devbrain.cz");
            Console.WriteLine("Email: info@devbrain.cz");
            Console.WriteLine("\n" + T("menu_select"));
            Console.ReadKey(true);
        }

        static void ShowOnlineLeaderboard()
        {
            lang = AppSettings?.Language ?? "en";
            Console.Clear();
            Console.WriteLine("\n" + T("online_leaderboard") + ":");
            Console.WriteLine("1. Alice - Level 100");
            Console.WriteLine("2. Bob - Level 98");
            Console.WriteLine("3. Carol - Level 95");
            Console.WriteLine("4. Dave - Level 90");
            Console.WriteLine("5. Eve - Level 88");
            Console.WriteLine("\n" + T("online_info"));
            Console.WriteLine("\n" + T("menu_select"));
            Console.ReadKey(true);
        }
    }
}
