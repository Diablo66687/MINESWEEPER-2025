using Xunit;
using ConsoleApp3;

public class MinefieldTests
{
    [Fact]
    public void Minefield_CorrectMineCount()
    {
        var field = new Minefield(10, 10, 15);
        int mineCount = 0;
        for (int x = 0; x < field.Width; x++)
            for (int y = 0; y < field.Height; y++)
                if (field.Grid[x, y].HasMine) mineCount++;
        Assert.Equal(15, mineCount);
    }

    [Fact]
    public void Minefield_RevealCell_ChangesState()
    {
        var field = new Minefield(5, 5, 3);
        field.Reveal(0, 0);
        Assert.Equal(Minefield.CellState.Revealed, field.Grid[0, 0].State);
    }

    [Fact]
    public void Minefield_ToggleFlag_Works()
    {
        var field = new Minefield(5, 5, 3);
        field.ToggleFlag(1, 1);
        Assert.Equal(Minefield.CellState.Flagged, field.Grid[1, 1].State);
        field.ToggleFlag(1, 1);
        Assert.Equal(Minefield.CellState.Hidden, field.Grid[1, 1].State);
    }

    [Fact]
    public void Minefield_WinCondition_Works()
    {
        var field = new Minefield(3, 3, 1);
        // Reveal all except mine
        for (int x = 0; x < field.Width; x++)
            for (int y = 0; y < field.Height; y++)
                if (!field.Grid[x, y].HasMine)
                    field.Reveal(x, y);
        bool allRevealed = true;
        for (int x = 0; x < field.Width; x++)
            for (int y = 0; y < field.Height; y++)
                if (!field.Grid[x, y].HasMine && field.Grid[x, y].State != Minefield.CellState.Revealed)
                    allRevealed = false;
        Assert.True(allRevealed);
    }
}
